import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;

public  class ScarchServlet extends HttpServlet
{
 public void doPost(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException 
	{
      PrintWriter pw=null;
      res.setContentType("text/html");
      pw=res.getWriter();
      String str=null;
      str=req.getParameter("srch");
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","masthan","mahil");
		PreparedStatement stmt=con.prepareStatement("select *from APCM where ADHARNO=?");
		stmt.setString(1,str);
			ResultSet rs=stmt.executeQuery();
				if(rs.next()==false){

						pw.println("<td align='center'>Not Found Data</td>");
					}
					else{
					pw.println("<table align='center'border='2'>");
			pw.println("<td align='center'>VIEW DETAILS</td><tr>");	
			pw.println("<td>ADHAR NO:::"+rs.getString(1)+"</td><tr><tr>");
			pw.println("<td>STUDENTNAME:::"+rs.getString(2)+"</td><tr><tr>");
			pw.println("<td>FATHERNAME:::"+rs.getString(3)+"</td><tr><tr>");
			pw.println("<td>MOTHERNAME:::"+rs.getString(4)+"</td><tr><tr>");
			pw.println("<td>EDUCATION:::"+rs.getString(5)+"</td><tr><tr>");
			pw.println("<td>JOIN DATE:::"+rs.getString(6)+"</td><tr><tr>");
			pw.println("<td>END DATE:::"+rs.getString(7)+"</td><tr><tr>");
			pw.println("<td>DATE OF BIRTH:::"+rs.getString(8)+"</td><tr><tr>");
			pw.println("<table>");

							}


			

		}catch(ClassNotFoundException ex){

		}catch(Exception e){

		}
	}
}