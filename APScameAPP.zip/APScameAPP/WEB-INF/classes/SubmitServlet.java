import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;

public  class SubmitServlet extends HttpServlet
{
 protected void doPost(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException 
	{
      PrintWriter pw=null;
      res.setContentType("text/html");
      pw=res.getWriter();
        String name1=null;
		String name2=null;
		String name3=null;
		String name4=null;
		String name5=null;
		String name6=null;
		String name7=null;
		String name8=null;
        name1=req.getParameter("adhar");
		name2=req.getParameter("name");
		name3=req.getParameter("fname");
		name4=req.getParameter("mname");
		name5=req.getParameter("edu");
		name6=req.getParameter("jdate");
		name7=req.getParameter("edate");
		name8=req.getParameter("date");
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","masthan","mahil");
		PreparedStatement stmt=con.prepareStatement("insert into APCM values(?,?,?,?,?,?,?,?)");
		    stmt.setString(1,name1);
        	stmt.setString(2,name2);
        	stmt.setString(3,name3);
        	stmt.setString(4,name4);
        	stmt.setString(5,name5);
        	stmt.setString(6,name6);
        	stmt.setString(7,name7);
        	stmt.setString(8,name8);
			int rs=stmt.executeUpdate();
			pw.println("<table align='center'border='2'>");
			pw.println("<td align='center'>VIEW DETAILS</td><tr>");	
			pw.println("<td>ADHAR NO:::"+name1+"</td><tr><tr>");
			pw.println("<td>STUDENTNAME:::"+name2+"</td><tr><tr>");
			pw.println("<td>FATHERNAME:::"+name3+"</td><tr><tr>");
			pw.println("<td>MOTHERNAME:::"+name4+"</td><tr><tr>");
			pw.println("<td>EDUCATION:::"+name5+"</td><tr><tr>");
			pw.println("<td>JOIN DATE:::"+name6+"</td><tr><tr>");
			pw.println("<td>END DATE:::"+name7+"</td><tr><tr>");
			pw.println("<td>DATE OF BIRTH:::"+name8+"</td><tr><tr>");
			pw.println("<table>");
		}

	catch( ClassNotFoundException ex1){
		pw.println("InternalError");
	}
	catch(Exception e){

}

}
}