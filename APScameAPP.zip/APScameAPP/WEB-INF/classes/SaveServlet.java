import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;

public  class SaveServlet extends HttpServlet
{
 protected void doPost(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException 
	{
      PrintWriter pw=null;
      res.setContentType("application/.pdf");
      pw=res.getWriter();
        String name1=null;
		String name2=null;
		String name3=null;
		String name4=null;
		String name5=null;
		String name6=null;
		String name7=null;
		String name8=null;
        name1=req.getParameter("adhar");
		name2=req.getParameter("name");
		name3=req.getParameter("fname");
		name4=req.getParameter("mname");
		name5=req.getParameter("edu");
		name6=req.getParameter("jdate");
		name7=req.getParameter("edate");
		name8=req.getParameter("date");
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","masthan","mahil");
		//PreparedStatement stmt=con.prepareStatement("insert into APCM values(?,?,?,?,?,?,?,?)");
		Statement stmt1=con.createStatement();
		  /*  stmt.setString(1,name1);
        	stmt.setString(2,name2);
        	stmt.setString(3,name3);
        	stmt.setString(4,name4);
        	stmt.setString(5,name5);
        	stmt.setString(6,name6);
        	stmt.setString(7,name7);
        	stmt.setString(8,name8);
			int rs=stmt.executeUpdate();*/
			ResultSet rs1=stmt1.executeQuery("select *from APCM ;");
			while(rs1.next()){
			pw.println("ADHAR NO:::"+rs1.getString(1));
			pw.println("STUDENTNAME:::"+rs1.getString(2));
			pw.println("FATHERNAME:::"+rs1.getString(3));
			pw.println("MOTHERNAME:::"+rs1.getString(4));
			pw.println("EDUCATION:::"+rs1.getString(5));
			pw.println("JOIN DATE:::"+rs1.getString(6));
			pw.println("END DATE:::"+rs1.getString(7));
			pw.println("DATE OF BIRTH:::"+rs1.getString(8));
		}

	}
	catch( ClassNotFoundException ex1){
		pw.println("InternalError");

	}catch(Exception e){

	}

	}
}
