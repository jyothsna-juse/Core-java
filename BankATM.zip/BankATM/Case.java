import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
class Case{
	public static void main(String args[]){
		JFrame jf=new JFrame("Case collect");
		jf.setSize(500,700);
		jf.setVisible(true);
		jf.setLocationRelativeTo(null);
		jf.setLayout(null);
		jf.getContentPane().setBackground(Color.BLUE);


		JLabel lb=new JLabel("Please Collect Your Cash");
		lb.setBounds(450,300,700,50);
		lb.setFont(new Font("Brush Script MT",Font.BOLD,40));
		jf.add(lb);
		jf.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});

	}
}