import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class ATMLogin{
		public static void main(String[] args){
		JFrame Jf=new JFrame("BankATM");
		Jf.setSize(500,700);
		Jf.setLayout(null);
		//Jf.getContentPane().setBackground(Color.BLUE); 
		Jf.setLocationRelativeTo(null);
		Jf.setVisible(true);
		 ImageIcon img2=new ImageIcon("mahil.jpeg");
		Image img3=img2.getImage().getScaledInstance(1500,800,Image.SCALE_SMOOTH);
		img2=new ImageIcon(img3);
		JLabel lb1=new JLabel(img2); 
		lb1.setBounds(0,0,1500,700);
		Jf.add(lb1);
		 ImageIcon img=new ImageIcon("mahi.jpeg");
		Image img1=img.getImage().getScaledInstance(200,150,Image.SCALE_SMOOTH);
		img=new ImageIcon(img1);
		JLabel lb2=new JLabel(img); 
		lb2.setBounds(5,6,300,200);
		lb1.add(lb2);
	     Panel pn=new Panel();
		pn.setBounds(680,300,200,260);
		pn.setBackground(Color.WHITE);
		pn.setLayout(null);
		pn.setVisible(true);
		lb1.add(pn);
		JButton bn4=new JButton("1"); 
		bn4.setBounds(10,10,50,50);
		bn4.setFont(new Font("Book Antiqua",Font.BOLD,20));
		JButton bn5=new JButton("2"); 
		bn5.setBounds(75,10,50,50);
		bn5.setFont(new Font("Book Antiqua",Font.BOLD,20));
		JButton bn6=new JButton("3"); 
		bn6.setBounds(140,10,50,50);
		bn6.setFont(new Font("Book Antiqua",Font.BOLD,20));
		JButton bn7=new JButton("4"); 
		bn7.setBounds(10,70,50,50);
		bn7.setFont(new Font("Book Antiqua",Font.BOLD,20));
		JButton bn8=new JButton("5"); 
		bn8.setBounds(75,70,50,50);
		bn8.setFont(new Font("Book Antiqua",Font.BOLD,20));
		JButton bn9=new JButton("6"); 
		bn9.setBounds(140,70,50,50);
		bn9.setFont(new Font("Book Antiqua",Font.BOLD,20));
		JButton bn10=new JButton("7"); 
		bn10.setBounds(10,135,50,50);
		bn10.setFont(new Font("Book Antiqua",Font.BOLD,20));
		JButton bn11=new JButton("8"); 
		bn11.setBounds(75,135,50,50);
		bn11.setFont(new Font("Book Antiqua",Font.BOLD,20));
		JButton bn12=new JButton("9"); 
		bn12.setBounds(140,135,50,50);
		bn12.setFont(new Font("Book Antiqua",Font.BOLD,20));
		JButton bn13=new JButton("+"); 
		bn13.setBounds(10,200,50,50);
		bn13.setFont(new Font("Book Antiqua",Font.BOLD,20));
		JButton bn14=new JButton("0"); 
		bn14.setBounds(75,200,50,50);
		bn14.setFont(new Font("Book Antiqua",Font.BOLD,20));
		JButton bn15=new JButton("-"); 
		bn15.setBounds(140,200,50,50);
		bn15.setFont(new Font("Book Antiqua",Font.BOLD,20));
	    pn.add(bn4);
		pn.add(bn5);
		pn.add(bn6);
		pn.add(bn7);
		pn.add(bn8);
		pn.add(bn9);
		pn.add(bn10);
		pn.add(bn11);
		pn.add(bn12);
		pn.add(bn13);
		pn.add(bn14);
		pn.add(bn15);

JLabel lb4=new JLabel("WELCOME TO ");
		lb4.setBounds(300,50,600,50);
		lb4.setForeground(Color.BLUE);
		lb4.setFont(new Font("Book Antiqua",Font.BOLD,50));
		lb1.add(lb4);
		JLabel lb9=new JLabel("STATE BANK OF INDIA");
		lb9.setBounds(450,130,500,50);
		lb9.setForeground(Color.BLUE);
		lb9.setFont(new Font("Arial",Font.BOLD,40));
		lb1.add(lb9);
		
		JLabel lb=new JLabel("Please Enter Your Pin ");
		lb.setBounds(20,300,500,50);
		lb.setForeground(Color.WHITE);
		lb.setFont(new Font("Book Antiqua",Font.BOLD,40));
		lb1.add(lb);
		final JPasswordField tf=new JPasswordField(); 
		tf.setBounds(440,300,200,50);
		tf.setFont(new Font("Book Antiqua",Font.BOLD,30));
		lb1.add(tf);
		JButton bn=new JButton("Enter");
		bn.setBackground(Color.GREEN);
		bn.setBounds(890,300,150,50);
		bn.setFont(new Font("Book Antiqua",Font.BOLD,30));
		lb1.add(bn);
		JButton bn1=new JButton("Clear");
		bn1.setBackground(Color.YELLOW); 
		bn1.setBounds(890,370,150,50);
		bn1.setFont(new Font("Book Antiqua",Font.BOLD,30));
		lb1.add(bn1);
		JButton bn2=new JButton("Cancel");
		bn2.setBackground(Color.RED); 
		bn2.setBounds(890,440,150,50);
		bn2.setFont(new Font("Book Antiqua",Font.BOLD,30));
		lb1.add(bn2);
		JButton bn3=new JButton(" "); 
		bn3.setBounds(890,510,150,50);
		bn3.setFont(new Font("Book Antiqua",Font.BOLD,30));
		lb1.add(bn3);
			bn1.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText("");
				}
			});
			bn2.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			System.exit(0);
		}
		});

bn4.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText(tf.getText() + "1");
				}
			});
bn5.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText(tf.getText() + "2");
				}
			});
bn6.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText(tf.getText() + "3");
				}
			});
bn7.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText(tf.getText() + "4");
				}
			});
bn8.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText(tf.getText() + "5");
				}
			});
bn9.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText(tf.getText() + "6");
				}
			});
bn10.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText(tf.getText() + "7");
				}
			});
bn11.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText(tf.getText() + "8");
				}
			});
bn12.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText(tf.getText() + "9");
				}
			});
bn13.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText(tf.getText() + "+");
				}
			});
bn14.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText(tf.getText() + "0");
				}
			});
bn15.addActionListener(new  ActionListener(){
				public void actionPerformed(ActionEvent e){
						tf.setText(tf.getText() + "-");
				}
			});

bn.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					String mahi=tf.getText();
					if(mahi.equals("9848")){
						JOptionPane.showMessageDialog(null,"success Password");
						 Banking.main(new String[]{"A","B"});
					
					}
					else{
						JOptionPane.showMessageDialog(null,"Invalid Password");
					}
						
			
				}
			
			});

	



		Jf.addWindowListener(new WindowAdapter(){
		public void windowClosing(WindowEvent e){
			System.exit(0);
		}
		});
	}
} 