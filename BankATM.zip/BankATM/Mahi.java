import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class Mahi{
		public static void main(String[] args){
		JFrame Jf=new JFrame("BankATM");
		Jf.setSize(500,700);
		Jf.setLayout(null);
		//Jf.getContentPane().setBackground(); 
		Jf.setLocationRelativeTo(null);
		Jf.setVisible(true);
		 ImageIcon img=new ImageIcon("mahil.jpeg");
		Image img1=img.getImage().getScaledInstance(1500,800,Image.SCALE_SMOOTH);
		img=new ImageIcon(img1);
		JLabel lb=new JLabel(img); 
		lb.setBounds(0,0,1500,700);
		Jf.add(lb);
		JLabel lb1=new JLabel("State Bank of India");
			lb1.setBounds(350,80,900,50);
			lb1.setFont(new Font("Arial",Font.BOLD,70));
			lb1.setForeground(Color.BLUE);
			lb.add(lb1);
			Button lb4=new Button("Banking");
			lb4.setBounds(1130,400,220,50);
			lb4.setFont(new Font("Arial",Font.BOLD,30));
			lb4.setBackground(Color.BLUE);
			lb.add(lb4);
				lb4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Nag.main(new String[] {"A","B"});
			}
		});
			
			Jf.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});

	}
}