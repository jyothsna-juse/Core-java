import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class Banking{
		public static void main(String[] args){
		JFrame Jf=new JFrame("BankATM");
		Jf.setSize(500,700);
		Jf.setLayout(null);
		//Jf.getContentPane().setBackground(); 
		Jf.setLocationRelativeTo(null);
		Jf.setVisible(true);
		 ImageIcon img=new ImageIcon("mahil.jpeg");
		Image img1=img.getImage().getScaledInstance(1500,800,Image.SCALE_SMOOTH);
		img=new ImageIcon(img1);
		JLabel lb=new JLabel(img); 
		lb.setBounds(0,0,1500,700);
		Jf.add(lb);
		JButton lb1=new JButton("DEPOSIT");
		lb1.setBounds(3,300,290,50);
		lb1.setBackground(Color.YELLOW); 
		lb1.setFont(new Font("Arial",Font.BOLD,30));
		lb.add(lb1);
		JButton lb2=new JButton("TRANSFER");
		lb2.setBounds(3,390,290,50);
		lb2.setBackground(Color.YELLOW); 
		lb2.setFont(new Font("Arial",Font.BOLD,30));
		lb.add(lb2);
		JButton lb3=new JButton("PIN CHANGE");
		lb3.setBounds(3,480,290,50);
		lb3.setBackground(Color.YELLOW); 
		lb3.setFont(new Font("Arial",Font.BOLD,30));
		lb.add(lb3);
		JButton lb4=new JButton("OTHERS");
		lb4.setBounds(3,580,290,50);
		lb4.setBackground(Color.YELLOW); 
		lb4.setFont(new Font("Arial",Font.BOLD,30));
		lb.add(lb4);
		JButton lb5=new JButton("FAST CASH");
		lb5.setBounds(1030,300,340,50);
		lb5.setBackground(Color.YELLOW); 
		lb5.setFont(new Font("Arial",Font.BOLD,30));
		lb.add(lb5);
		JButton lb6=new JButton("CASH WITHDRAWAL");
		lb6.setBounds(1030,390,340,50);
		lb6.setBackground(Color.YELLOW); 
		lb6.setFont(new Font("Arial",Font.BOLD,30));
		lb.add(lb6);
		JButton lb7=new JButton("BALANCE ENQUIRY");
		lb7.setBounds(1030,480,340,50);
		lb7.setBackground(Color.YELLOW); 
		lb7.setFont(new Font("Arial",Font.BOLD,30));
		lb.add(lb7);
		JButton lb8=new JButton("MINI STATEMENT");
		lb8.setBounds(1030,580,340,50);
		lb8.setBackground(Color.YELLOW); 
		lb8.setFont(new Font("Arial",Font.BOLD,30));
		lb.add(lb8);
		JLabel lb9=new JLabel("STATE BANK OF INDIA");
		lb9.setBounds(450,60,500,50);
		lb9.setForeground(Color.BLUE);
		lb9.setFont(new Font("Arial",Font.BOLD,40));
		lb.add(lb9);
		JLabel lb10=new JLabel("Select Transaction");
		lb10.setBounds(550,150,500,50);
		lb10.setForeground(Color.BLUE);
		lb10.setFont(new Font("Arial",Font.BOLD,30));
		lb.add(lb10);

		lb6.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Withdrowl.main(new String[] {"A","B"});
			}
		});



		Jf.addWindowListener(new WindowAdapter(){
		public void windowClosing(WindowEvent e){
			System.exit(0);
		}
		});
	}
} 