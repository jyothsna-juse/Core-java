import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class Amount{
		public static void main(String[] args){
		JFrame Jf=new JFrame("BankATM");
		Jf.setSize(500,700);
		Jf.setLayout(null); 
		Jf.setLocationRelativeTo(null);
		Jf.setVisible(true);
		 ImageIcon img=new ImageIcon("mahil.jpeg");
		Image img1=img.getImage().getScaledInstance(1500,800,Image.SCALE_SMOOTH);
		img=new ImageIcon(img1);
		JLabel lb=new JLabel(img); 
		lb.setBounds(0,0,1500,700);
		Jf.add(lb);
		JLabel lb1=new JLabel("State Bank of India");
			lb1.setBounds(350,80,900,50);
			lb1.setFont(new Font("Arial",Font.BOLD,70));
			lb1.setForeground(Color.BLUE);
			lb.add(lb1);
			JLabel lb2=new JLabel("Please Enter Amount");
			lb2.setBounds(480,150,600,50);
			lb2.setFont(new Font("Arial",Font.BOLD,40));
			lb2.setForeground(Color.BLUE);
			lb.add(lb2);
			JLabel lb3=new JLabel("Rs");
			lb3.setBounds(480,450,100,50);
			lb3.setFont(new Font("Arial",Font.BOLD,60));
			lb3.setForeground(Color.BLUE);
			lb.add(lb3);
			Button lb4=new Button("Press if YES");
			lb4.setBounds(1130,500,220,50);
			lb4.setFont(new Font("Arial",Font.BOLD,30));
			lb4.setBackground(Color.YELLOW);
			lb.add(lb4);
			Button lb5=new Button("Press if No");
			lb5.setBounds(1130,600,220,50);
			lb5.setFont(new Font("Arial",Font.BOLD,30));
			lb5.setBackground(Color.YELLOW);
			lb.add(lb5);
			final TextField ta=new TextField("");
			ta.setBounds(600,450,250,50);
			ta.setFont(new Font("Arial",Font.BOLD,30));
			lb.add(ta);
			lb4.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
						String nag=ta.getText();

						Case.main(new String[] {"A","B"});
			}

			});


		Jf.addWindowListener(new WindowAdapter(){
		public void windowClosing(WindowEvent e){
			System.exit(0);
			}
		});


	}
}