import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class Withdrowl{
		public static void main(String[] args){
		JFrame Jf=new JFrame("BankATM");
		Jf.setSize(500,700);
		Jf.setLayout(null);
		//Jf.getContentPane().setBackground(); 
		Jf.setLocationRelativeTo(null);
		Jf.setVisible(true);
		 ImageIcon img=new ImageIcon("mahil.jpeg");
		Image img1=img.getImage().getScaledInstance(1500,800,Image.SCALE_SMOOTH);
		img=new ImageIcon(img1);
		JLabel lb=new JLabel(img); 
		lb.setBounds(0,0,1500,700);
		Jf.add(lb);
		JLabel lb1=new JLabel("State Bank of India");
			lb1.setBounds(350,80,900,50);
			lb1.setFont(new Font("Arial",Font.BOLD,70));
			lb1.setForeground(Color.BLUE);
			lb.add(lb1);
			Button lb2=new Button("From Corrent");
			lb2.setBounds(1130,500,220,50);
			lb2.setFont(new Font("Arial",Font.BOLD,30));
			lb2.setBackground(Color.YELLOW);
			lb.add(lb2);
			Button lb3=new Button("From Saving");
			lb3.setBounds(1130,600,220,50);
			lb3.setFont(new Font("Arial",Font.BOLD,30));
			lb3.setBackground(Color.YELLOW);
			lb.add(lb3);


		lb2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Amount.main(new String[] {"A","B"});
			}
		});
	     lb3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Amount.main(new String[] {"A","B"});
			}
		});
		
		Jf.addWindowListener(new WindowAdapter(){
		public void windowClosing(WindowEvent e){
			System.exit(0);
			}
		});
	}
} 